# Carreira de Craque v1.58.4 — Correção definitiva da classificação

- A classificação passa a considerar somente partidas explicitamente marcadas como disputadas (`played === true`).
- Para jogos do clube controlado, o placar salvo no histórico da carreira é a fonte prioritária; isso impede que um placar residual/invertido no calendário transforme derrota em vitória.
- A deduplicação identifica cada confronto por rodada, mandante e visitante, sem permitir que placares divergentes contem o mesmo jogo duas vezes.
- A tabela é reconstruída do zero a partir dos resultados válidos, evitando somar estatísticas antigas novamente.
- Mantém os fluxos de coletiva pós-jogo e a correção da rodada 5 do Sub-20 da versão anterior.
