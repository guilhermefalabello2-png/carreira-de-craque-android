# v1.62.25 — Escudos offline de todos os clubes

- Ampliado o catálogo de cache do Service Worker para todos os endereços de escudos utilizados pelo jogo (Brasil/Séries A, B e C, Premier League e LaLiga).
- Os escudos locais já existentes continuam empacotados no ZIP e são incluídos no cache do aplicativo.
- Os escudos externos são pré-carregados no cache persistente do navegador durante a instalação/primeira abertura com internet; depois de armazenados, podem ser exibidos offline.
- O cache é atualizado com uma nova chave de versão para substituir o catálogo limitado anterior.
- A identidade/ID dos clubes, elencos, uniformes, calendário e dados de carreira não foram alterados.

**Limitação técnica transparente:** imagens servidas por terceiros não podem ser incorporadas como arquivos originais ao pacote nesta execução sem acesso de rede aos servidores. Por isso, escudos externos precisam ser baixados uma vez na primeira instalação com internet. Se um servidor bloquear o download, aquele escudo não poderá ser garantido offline até conseguir ser armazenado.
