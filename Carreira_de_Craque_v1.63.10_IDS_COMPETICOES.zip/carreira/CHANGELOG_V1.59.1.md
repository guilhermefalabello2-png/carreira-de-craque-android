# Carreira de Craque v1.59.1 — Copa do Brasil no calendário

- A Copa do Brasil agora aparece diretamente em **Partidas → Calendário da temporada**.
- A agenda mostra os confrontos do clube da carreira, fase, data, mando, ida/volta, placar e situação (agendado/disputado).
- Clubes com BYE recebem indicação de classificação automática para a segunda fase.
- Adicionado símbolo vetorial minimalista da Copa do Brasil/CBF no calendário e nas telas da competição.
- Atalho para abrir a tela completa da Copa do Brasil a partir do calendário.
- Limpeza inicial única dos saves de carreira autorizada pelo usuário para começar os testes desta versão; não remove arquivos de elencos, escudos ou assets.

## Verificações
- Sintaxe JavaScript verificada com Node.js.
- ZIP verificado com `unzip -t`.
- A renderização no navegador/Android ainda requer validação prática.
