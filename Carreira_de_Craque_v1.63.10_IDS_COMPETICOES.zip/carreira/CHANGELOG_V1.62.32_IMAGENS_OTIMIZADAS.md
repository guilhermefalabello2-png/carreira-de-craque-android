# v1.62.32 — Imagens otimizadas

- Otimização dos arquivos PNG dos troféus Série A e Série B para reduzir o tamanho do pacote.
- Sem alterações na lógica de partidas, tabelas, carreiras ou salvamentos.
- Metadados do pacote e título atualizados para v1.62.32.
