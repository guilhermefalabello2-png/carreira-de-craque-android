# v1.62.3 — Botão COMEÇAR NOVA TEMPORADA

- Padronizado o botão de temporada concluída para **COMEÇAR NOVA TEMPORADA** nas telas Início e Partidas.
- No Sub-20, a opção de permanecer na base agora usa o mesmo texto; a opção de promoção ao profissional continua separada.
- Mantida a lógica existente de geração de calendário, atualização de temporada, divisões brasileiras A/B/C e Premier League.
