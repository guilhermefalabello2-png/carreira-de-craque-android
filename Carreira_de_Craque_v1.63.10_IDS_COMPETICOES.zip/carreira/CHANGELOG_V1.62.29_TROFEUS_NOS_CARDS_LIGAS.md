# Carreira de Craque v1.62.29 — Troféus nos cards de Ligas

- Removida a galeria de troféus da tela inicial de LIGAS.
- Removidos os banners grandes de troféus das telas internas de campeonatos.
- Os PNGs agora aparecem no espaço exato anteriormente ocupado pelas bandeiras/ícones nos cards de seleção de campeonatos.
- Brasil: Série A, Série B, Série C, Copa do Brasil e Sub-20.
- Europa: Premier League e LaLiga.
- Ligas ainda indisponíveis (Serie A TIM, Ligue 1 e Bundesliga) mantêm seus indicadores de país e o status EM BREVE.
- Nenhuma lógica de partidas, tabelas, calendário, clubes ou salvamentos foi alterada.
