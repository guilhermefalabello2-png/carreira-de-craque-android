# Carreira de Craque v1.54.2 — Recuperação de Conquista Sub-20

- Recupera metadados de títulos Sub-20 em temporadas anteriores quando a tabela final completa já está salva, mas posição/campeão foram gravados incorretamente.
- A recuperação exige exatamente 20 clubes únicos e 38 partidas por clube, usa os mesmos critérios da classificação Sub-20 e só então corrige posição e campeão.
- Não cria títulos a partir de temporadas incompletas e não altera calendários, resultados, elencos ou regras de partidas.
- A correção é aplicada ao abrir Conquistas e salva os metadados recuperados no save atual.
