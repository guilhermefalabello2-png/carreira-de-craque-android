# v1.62.35 — Correção das estrelas dos clubes brasileiros

- Corrigida a classificação que fazia clubes brasileiros receberem 3 estrelas durante carreiras na Inglaterra.
- Criada uma tabela explícita de estrelas para todos os clubes brasileiros das Séries A, B e C e clubes convidados da Copa do Brasil.
- A classificação Sub-20 continua separada e não sobrescreve a avaliação profissional.
- Clubes ingleses e espanhóis mantêm suas próprias avaliações.
- Nenhum sistema de partidas, elenco, escudos ou salvamentos foi alterado.
