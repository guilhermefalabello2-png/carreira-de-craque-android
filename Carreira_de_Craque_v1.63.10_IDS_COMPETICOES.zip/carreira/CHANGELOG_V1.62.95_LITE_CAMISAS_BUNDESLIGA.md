# Carreira de Craque v1.62.95 LITE — Camisas da Bundesliga

- Adicionadas camisas titulares vetoriais próprias para os 18 clubes da Bundesliga.
- Cada clube recebeu combinação de cores e padrão visual inspirado em sua identidade tradicional.
- Escudos da Bundesliga foram integrados à área do peito das camisas quando disponíveis nos arquivos do jogo.
- As camisas acompanham automaticamente o clube do atleta e aparecem no catálogo visual e nas representações que usam o uniforme.
- Alteração restrita ao visual dos uniformes; calendários, partidas, tabelas, elencos e demais ligas preservados.
- Os desenhos são recriações estilizadas, não reproduções oficiais licenciadas nem cópias exatas de todos os detalhes/patrocínios.
