# Carreira de Craque v1.62.59 — Ajuste dos botões de pênaltis

- A cobrança manual fica restrita exclusivamente ao atleta do usuário.
- Cobranças dos companheiros e dos adversários são resolvidas automaticamente; o usuário apenas revela a próxima cobrança.
- Removido o visual laranja dos botões de direção.
- Direções com menos de 70% ficam vermelhas; somente direções com 70% ou mais ficam verdes. Assim, MEIO com 45% aparece vermelho.
- Mantida a disposição horizontal ESQUERDA | MEIO | DIREITA, com MEIO centralizado.
- Não altera placares oficiais, estatísticas da carreira, elencos ou escudos.
