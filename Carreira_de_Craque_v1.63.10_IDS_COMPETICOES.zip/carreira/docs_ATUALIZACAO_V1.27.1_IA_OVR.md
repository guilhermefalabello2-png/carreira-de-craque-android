# Atualização v1.27.2 — IA por estrelas e OVR

- A força da equipe agora combina a avaliação em estrelas do clube com a média do OVR estimado dos 11 atletas mais fortes.
- Ajustada a simulação para que diferenças de força influenciem chances de gol de forma gradual, sem determinar o resultado.
- Mantida variância por partida e vantagem de mando, permitindo zebras de equipes menores.
- No elenco da Premier League, os OVRs de gameplay estimados agora variam também conforme a avaliação do clube, além da posição e de uma variação individual determinística.
- OVRs são estimativas internas de gameplay, não avaliações oficiais dos jogadores.

Validação: sintaxe JavaScript verificada com Node.js. Não foi realizado teste visual/end-to-end no navegador.
