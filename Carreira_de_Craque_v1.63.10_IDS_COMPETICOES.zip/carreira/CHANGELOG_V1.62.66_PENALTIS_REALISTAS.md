# Carreira de Craque v1.62.66 — Pênaltis Realistas

- Substituído o sistema previsível de conversão fixa por resolução probabilística variável.
- Cobranças agora consideram qualidade do cobrador, evolução individual, overall, cansaço, pressão do placar e qualidade do goleiro.
- Resultados diferenciados: gol, defesa do goleiro, bola na trave ou cobrança para fora.
- IA não usa mais percentuais fixos de 70%, 72% ou 75%; cada cobrança tem variação própria e os batedores são escolhidos entre os atletas disponíveis.
- Removidos percentuais de conversão exibidos nos botões, que davam a impressão de chances rígidas por direção.
- Aplicado o mesmo motor de cobrança à partida, disputa oficial da Copa do Brasil e modo de teste.
- Mantidos o fluxo de controle do atleta do usuário e o registro dos pênaltis fora das estatísticas de gols da carreira.
