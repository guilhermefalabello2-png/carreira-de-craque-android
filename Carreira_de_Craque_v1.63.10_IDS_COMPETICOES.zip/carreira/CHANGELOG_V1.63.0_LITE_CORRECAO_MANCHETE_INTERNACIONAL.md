# v1.63.0 LITE — Correção de identificação do Internacional

- Corrigida a identificação da imprensa italiana nas coletivas e manchetes pós-jogo.
- A detecção da Serie A italiana agora compara nomes completos dos clubes cadastrados, em vez de procurar a sequência `inter` dentro de qualquer nome.
- O Internacional de Porto Alegre deixa de ser confundido com a Internazionale de Milão.
- A imprensa brasileira (`ge`) é mantida para partidas brasileiras; a imprensa italiana continua sendo usada para clubes e competições da Serie A Enilive.
- Nenhuma tabela, elenco, calendário, simulação ou sistema de partidas foi alterado.
