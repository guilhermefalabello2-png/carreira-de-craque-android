# v1.52.8 — Validação do encerramento da temporada

- A temporada profissional só é gravada no Legado após todas as 38 rodadas e os 380 jogos estarem concluídos com placares válidos.
- Se ainda houver jogos pendentes, o encerramento não grava posição nem campeão e informa que a temporada continua aberta.
- O troféu no Legado exige posição final registrada como 1º lugar e confirmação da classificação histórica.
- Atualizado o cache do service worker para evitar reaproveitar a versão anterior.

Nota: esta proteção impede novos registros prematuros. Ela não pode reconstruir dados históricos que já tenham sido sobrescritos no salvamento.
