# v1.62.39 — Escudos da Roma e Juventus corrigidos

- Roma agora usa escudo SVG local no projeto, evitando falha da URL externa anterior.
- Juventus agora usa escudo branco com o símbolo preto, conforme solicitado.
- Os dois escudos estão incluídos no pacote e não dependem de hospedagem externa.
- Nenhuma alteração em elencos, partidas, tabelas, carreiras ou demais clubes.
