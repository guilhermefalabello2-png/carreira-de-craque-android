# Carreira de Craque v1.62.97 LITE — Nomes das ligas

- Removido o sufixo “(Profissional)” das opções de ligas no seletor “Escolher país e clube”.
- Alemanha passa a aparecer como “Alemanha - Bundesliga”.
- Brasil Sub-20 permanece como “Brasil Sub-20”.
- Nenhuma regra de competição, elenco, estrela, uniforme, escudo ou salvamento foi alterada.
