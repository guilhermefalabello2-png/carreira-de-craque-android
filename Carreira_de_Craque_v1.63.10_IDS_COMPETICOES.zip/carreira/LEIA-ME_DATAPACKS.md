# Como criar um patch de escudos — Carreira de Craque v1.63.5

O patch é um arquivo `.zip` com esta estrutura:

```
MeuPatch.zip
├── patch.json
└── escudos/
    ├── flamengo.webp
    └── palmeiras.webp
```

Exemplo de `patch.json`:

```json
{
  "format": "CC-PATCH",
  "version": 1,
  "name": "Meu Patch Brasil",
  "crests": {
    "BRA-FLAMENGO": "escudos/flamengo.webp",
    "BRA-PALMEIRAS": "escudos/palmeiras.webp"
  }
}
```

- A chave de cada imagem é o ID permanente do clube, não o nome exibido.
- Imagens aceitas: PNG, JPG/JPEG, WebP e SVG.
- Limite atual: 2 MB por imagem.
- Não inclua pastas `..` ou caminhos absolutos no manifesto.
- Instalação: menu inicial → **Colocar Patch** → selecionar o ZIP → **Instalar Patch**.
- Os escudos instalados ficam no armazenamento local do navegador (IndexedDB), separados dos saves.
- O jogo não contém escudos de clubes embutidos nesta edição LITE. Sem patch, os clubes aparecem com iniciais.
