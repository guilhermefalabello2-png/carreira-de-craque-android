# Carreira de Craque v1.58.2 — Atualização imediata da coletiva na tela Início

- Corrigido o retorno do relatório pós-jogo para a tela Início.
- Ao tocar em **IR PARA INÍCIO**, a tela é renderizada imediatamente com o compromisso de coletiva pendente.
- Adicionada uma segunda validação de renderização no próximo frame para evitar que a tela inicial fique visualmente desatualizada.
- Reforçado o vínculo do botão **INICIAR COLETIVA PÓS JOGO**.
- Mantida a trava que impede iniciar outra partida ou avançar a temporada antes de concluir a coletiva.
