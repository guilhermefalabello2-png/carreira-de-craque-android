# Carreira de Craque v1.46.5 — Série C funcional e zonas G4/Z4

- A tabela da Série C destaca visualmente o G4 em verde, com borda lateral e legenda explícita de acesso à Série B.
- Série A passa a destacar o G4 em verde e o Z4 em vermelho; os quatro últimos são rebaixados à Série B.
- Série B destaca G4 (acesso à Série A) e Z4 (rebaixamento à Série C).
- A Série C mantém os quatro primeiros promovidos à Série B ao final da temporada.
- A progressão anual das divisões aplica automaticamente quatro acessos da Série B à A, quatro rebaixamentos da A à B, quatro acessos da C à B e quatro rebaixamentos da B à C.
- A tabela e a legenda deixam claras as zonas esportivas, sem alterar a simulação de partidas já existente.
