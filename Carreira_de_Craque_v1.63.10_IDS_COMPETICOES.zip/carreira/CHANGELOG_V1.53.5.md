# v1.53.5 — Legado profissional: validação estrita de temporada

## Investigação comparativa
- O Sub-20 obtém a classificação de `sub20Load()`/`sub20Table()` a partir do campeonato separado persistido por carreira; `finishBaseSeason()` grava a tabela final desse sistema.
- O profissional grava a partir de `state.fixtures` em `finishSeason()` e reconstrói a classificação final dos 380 jogos. O Legado é compartilhado na interface, mas as fontes de dados e os fluxos de encerramento não são iguais.

## Causa corrigida
- A validação anterior aceitava registros históricos sem `finalized: true` (bastava não serem explicitamente `false`).
- Também aceitava partidas históricas sem carimbo de temporada/competição, porque só rejeitava carimbos divergentes quando existiam. Um snapshot antigo ou de outra temporada podia, portanto, ser tratado como prova de título se os campos legados de posição/campeão coincidissem.
- Registros antigos sem prova suficiente agora são preservados no histórico, mas não podem gerar troféu/título verificado nem uma posição profissional apresentada como confirmada.
- Remove a segunda chamada redundante de registro do título no encerramento profissional; o registro é tentado uma única vez após a validação.

## Alterações
- Exige `finalized === true` para reconhecer resultado histórico como definitivo.
- Exige que cada partida profissional tenha `season` e `competitionId` exatamente iguais aos do registro.
- Mantém a fonte de dados e o fluxo do Sub-20 sem alterações.
- O contador de títulos da interface passa a contar apenas conquistas profissionais comprovadas; totais antigos não verificáveis continuam armazenados e são informados separadamente, sem serem apagados.
- Atualiza a chave do cache do service worker para que a nova versão substitua o shell anterior.

## Testes
- Regressão profissional: 1º, 2º, 5º lugar, temporada incompleta, metadados ausentes, temporada errada, registro idempotente e recarga do save.
- Comparativo Sub-20: tabela isolada e verificação de campeão preservada.
