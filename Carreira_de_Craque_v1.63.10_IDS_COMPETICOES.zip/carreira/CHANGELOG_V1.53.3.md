# v1.53.3 — Validação do campeão no Legado

- O Legado só exibe o troféu quando a classificação final do registro da temporada confirma o 1º lugar.
- Campeonatos profissionais exigem 380 partidas concluídas, placares válidos e recálculo da tabela a partir dos jogos persistidos.
- Registros antigos sem evidência suficiente deixam de ser tratados como títulos confirmados, sem apagar o histórico salvo.
- Registros de temporada incluem identificador da carreira, competição, estado de conclusão e campeão; corrigida também a identificação histórica da Série C.
- Incluídos testes de regressão para vice-campeão, tabela sem evidência e temporada com partidas pendentes.
