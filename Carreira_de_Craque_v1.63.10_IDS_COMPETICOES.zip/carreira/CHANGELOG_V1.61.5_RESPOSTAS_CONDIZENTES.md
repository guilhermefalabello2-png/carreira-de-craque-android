# v1.61.5 — Respostas coerentes com cada pergunta

- Refeito o gerador de respostas das coletivas normais e de clássicos.
- As cinco personalidades agora preservam o assunto perguntado; mudam o tom, não desviam do tema.
- Criadas respostas específicas para ajustes táticos, preparação, desempenho individual, gols, assistências, cartões, expulsões, grupo, rivalidade e análise do jogo.
- As respostas consideram vitória, empate ou derrota da equipe do jogador.
- Perguntas sobre banco e preparação usam respostas próprias para quem não entrou em campo.
- Mantidas as perguntas, jornalistas, emissoras, efeitos e demais sistemas existentes.

Validação: JavaScript extraído de `index.html` aprovado em `node --check`.
