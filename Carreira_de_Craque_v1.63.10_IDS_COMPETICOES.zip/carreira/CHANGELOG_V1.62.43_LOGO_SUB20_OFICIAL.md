# v1.62.43 — Logo do Brasileirão Sub-20

- Substituída a imagem antiga exibida no espaço do Brasileirão Sub-20 em **Ligas** pela imagem enviada pelo usuário.
- A imagem foi convertida para PNG e salva no caminho local `assets/trofeus/trofeu-sub20.png`, que já é utilizado pela interface de Ligas.
- Mantidos os logos das demais competições e todos os sistemas do jogo.
- Atualizado o cache do service worker para forçar a leitura do novo PNG.
