# Carreira de Craque v1.62.86 — Edição Lite

- Base funcional: v1.62.85.
- Mantidas as funções e ligas da edição normal.
- Otimização sem perda de transparência: PNGs convertidos para paleta otimizada quando menor, mantendo as dimensões originais.
- Removidos somente arquivos locais de depuração/teste que não são usados pelo jogo.
- Cache do Service Worker versionado para instalar os arquivos Lite atualizados.
- Nenhuma carreira/salvamento foi apagado ou alterado.
