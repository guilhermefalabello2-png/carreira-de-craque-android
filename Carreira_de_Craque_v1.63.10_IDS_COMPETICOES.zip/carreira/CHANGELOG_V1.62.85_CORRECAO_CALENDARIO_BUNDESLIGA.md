# v1.62.85 — Correção do calendário da Bundesliga

- Corrigida a recuperação do calendário para carreiras de clubes da Bundesliga.
- O fluxo de recuperação agora reconhece os 18 clubes alemães e reconstrói a temporada com 34 rodadas (turno e returno), tabela e associação correta ao clube do jogador.
- Corrigida a inicialização ao reabrir uma carreira alemã: o calendário de 18 clubes/34 rodadas não é mais confundido com o formato brasileiro ou com ligas de 20 clubes/38 rodadas.
- Preservados os calendários e dados das demais ligas; nenhuma limpeza de saves foi executada.
