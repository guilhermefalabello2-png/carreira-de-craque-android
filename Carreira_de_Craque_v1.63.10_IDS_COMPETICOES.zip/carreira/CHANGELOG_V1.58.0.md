# Carreira de Craque v1.58.0 — Coletivas Pós-Jogo

- Adicionada coletiva obrigatória após partidas em que o atleta participou (minutos > 0), em todas as competições que usam o relatório pós-jogo comum.
- Relatório final apresenta botão para abrir a coletiva; a carreira não pode iniciar outra partida nem avançar temporada enquanto a entrevista estiver pendente.
- Três perguntas por coletiva, selecionadas conforme resultado, margem, nota, gols, assistências e cartões.
- Jornalistas fictícios e veículos variados; evita repetir os últimos jornalistas quando houver alternativas.
- Quatro respostas com posturas distintas e consequências moderadas em moral, confiança, reputação e confiança do treinador.
- Manchete do dia seguinte gerada a partir do resultado e da postura escolhida.
- Respostas e progresso ficam registrados dentro do resultado da partida, com histórico compacto e sem novo armazenamento por partida fora do save.
- Partidas em que o atleta não entrou não iniciam coletiva, pois ele não participou do jogo.
