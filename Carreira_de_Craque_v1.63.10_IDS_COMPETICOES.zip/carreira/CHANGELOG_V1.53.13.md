# v1.53.13 — Correção do intervalo e da rodada

- Recupera a rodada correta a partir da identidade da partida salva (temporada, número da rodada, mandante e visitante).
- Faz a recuperação acontecer antes da sincronização dos calendários, evitando que um contador de rodada desatualizado apague partidas futuras.
- Ao finalizar, confirma que a sessão e o confronto são os mesmos antes de registrar o placar.
- Não inventa resultado nem marca uma partida diferente como disputada.
