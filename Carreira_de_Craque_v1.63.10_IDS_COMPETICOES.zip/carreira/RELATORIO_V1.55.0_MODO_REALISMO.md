# Carreira de Craque v1.55.0 — investigação e Modo Realismo

## Causa encontrada

O motor anterior tinha uma função central (`matchGoalRates`), mas as diferenças técnicas eram comprimidas: as estrelas tinham peso de apenas `0,035` por estrela, os atributos posicionais tinham coeficientes muito pequenos e os logs de força eram limitados a `±0,68`. Além disso, duas rotas não usavam o motor central: o avanço do Sub-20 usava `leagueStrength` + Poisson próprio, e as ligas brasileiras paralelas/Sub-20 tinham geradores aleatórios de 0–3 gols.

## Alterações

- `matchRosterProfile`: continua a reunir OVR dos 11 melhores disponíveis por posição, goleiro, defesa, meio, ataque e reservas.
- `matchGoalRates`: recalibrada; estrelas têm influência residual relevante e OVR posicional influencia ataque/defesa, sem ser a única fonte de força.
- `simulateScore`: motor comum de placar, utilizado por partidas de calendário e simulação de segmentos da partida jogada.
- `simulateLeagueGame`: segue usando `simulateScore`, portanto cobre a liga principal, outras ligas e rodadas automáticas que passam por essa função.
- Sub-20 (`sub20AdvanceToCareerRound` e `sub20SimRound`) e Séries A/B/C paralelas (`brazilWorldSim` e `brazilWorldAutoAdvance`) agora também chamam `simulateScore` quando Realismo está ativado.
- Removido o bônus artificial de recuperação do placar para o lado do jogador no simulador de partida em tempo real.
- Configuração global `cc_match_realism_v155`, armazenada como um único valor leve no `localStorage`. Padrão: ativado. Desativar restaura a fórmula anterior v1.54.0.

## Testes automatizados

Foram executadas 10.000 partidas por cenário (60.000 partidas no modo Realismo), usando escalações sintéticas controladas para testar o motor sem depender de dados específicos de uma carreira. A equipe A é mandante em todos os cenários. “Goleada” significa diferença de 3 ou mais gols.

| Cenário | Vitória A | Empate | Vitória B | Gols/jogo | Goleadas |
|---|---:|---:|---:|---:|---:|
| 5★ x 1★ | 74,44% | 17,19% | 8,37% | 2,78 | 27,99% |
| 4★ x 2★ | 63,90% | 21,54% | 14,56% | 2,69 | 19,09% |
| 3★ x 3★ | 43,21% | 26,74% | 30,05% | 2,44 | 10,61% |
| 2★ x 2★ | 43,44% | 26,91% | 29,65% | 2,45 | 10,74% |
| Estrelas iguais, OVR diferente | 57,47% | 23,61% | 18,92% | 2,58 | 15,86% |
| Estrelas diferentes, OVR semelhante | 53,06% | 25,25% | 21,69% | 2,53 | 14,02% |

Placares mais frequentes por cenário foram 2–0, 1–0, 3–0 e 2–1 no 5★ x 1★; 1–0, 2–0, 1–1 e 2–1 no 4★ x 2★; e 1–1, 1–0, 0–1 e 2–1 nos confrontos equilibrados.

Foi executada também uma amostra de 10.000 partidas com o modo desativado para confirmar que a chave alterna para a fórmula legada. A escolha fica isolada em uma única chave e não altera saves ou dados de temporada.

## Escopo e limitações da validação

A análise estatística usa elencos sintéticos de teste e valida a função real `matchGoalRates`/`simulateScore` extraída do código do jogo. Não é um teste de temporada completa no Android nem uma afirmação de que os elencos de todos os clubes foram auditados manualmente. A integração do Sub-20 e das ligas paralelas foi verificada por inspeção dos pontos de chamada no código; o comportamento final no dispositivo ainda precisa de teste prático.
