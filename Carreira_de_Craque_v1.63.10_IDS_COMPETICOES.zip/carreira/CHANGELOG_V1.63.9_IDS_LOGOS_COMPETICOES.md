# v1.63.9 — IDs de logos das competições

- Adicionado registro central de IDs estáveis para logos de competições.
- IDs incluem Brasileirão Série A, B e C, Copa do Brasil, Sub-20 e ligas europeias presentes no projeto.
- Esta entrega é o projeto-fonte para compilação Android via GitHub Actions; não é um APK pré-compilado.
- O APK deve ser gerado pelo workflow `.github/workflows/android-apk.yml` para preservar a estrutura correta do Capacitor.
