# v1.48.7 — Escudo do Ipswich Town

- Corrigida a URL do escudo do Ipswich Town, que apontava para uma imagem ESPN que não estava sendo exibida.
- O escudo usa agora a imagem transparente do emblema do Ipswich Town.
- Nenhuma outra mudança de interface ou gameplay. Esta versão parte da v1.48.5 para não incluir a ideia do mascote Falcone no topo.
