# v1.61.8 — Camisa correta no anúncio de transferência

- O destaque visual da notícia de transferência agora reutiliza o mesmo SVG de camisa já usado pelo jogo.
- A camisa é renderizada com o clube de destino, respeitando o modelo, as cores, o padrão e o número do uniforme configurado no próprio jogo.
- Removida a camisa genérica branca/colorida desenhada separadamente no anúncio.
- Nenhuma outra tela ou sistema foi alterado.
