# v1.62.23 — Copa do Brasil acessível em carreiras europeias

- Corrigida a abertura da Copa do Brasil em Ligas para carreiras na Europa.
- Participantes da Copa do Brasil agora são sempre montados a partir das Séries A, B e C brasileiras, sem usar a divisão da carreira europeia.
- Saves com participantes inválidos (por exemplo, clubes espanhóis no torneio nacional) são reconstruídos com os 64 clubes brasileiros, preservando o histórico de campeões.
- A simulação automática das partidas da Copa continua avançando enquanto o atleta atua na Europa; o atleta europeu não é inserido como participante da competição.
