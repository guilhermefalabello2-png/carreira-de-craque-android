# Carreira de Craque — v1.60.6

- Refinado o desenho das camisas de Vitória, Grêmio, Botafogo e Athletico Paranaense para aproximar as faixas, proporções e cores das quatro referências enviadas.
- As camisas de Vitória e Botafogo usam três faixas pretas verticais mais largas e distribuídas pelo corpo.
- A camisa do Grêmio mantém as três faixas pretas horizontais sobre o azul-celeste.
- As faixas vermelhas do Athletico Paranaense foram corrigidas para a diagonal ascendente da referência.
- O uniforme do Santos foi mantido sem alterações.
- A lógica usa o clube atual do atleta e funciona tanto no Profissional quanto no Sub-20.
- Nenhum sistema de carreira, elenco, partidas ou salvamento foi intencionalmente alterado.
