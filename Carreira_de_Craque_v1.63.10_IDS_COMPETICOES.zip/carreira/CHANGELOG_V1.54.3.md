# v1.54.3 — Início limpo de carreira

- Limpeza única dos saves de carreira na primeira abertura desta versão, conforme autorização do usuário.
- Remove o save principal, a carreira ativa, os formatos legados e as tabelas Sub-20 vinculadas às carreiras antigas.
- Preserva elencos, escudos, assets, configurações e sistemas do jogo.
- A limpeza é marcada como concluída para não apagar a nova carreira em aberturas futuras.
