# Carreira de Craque v1.53.16 — Salvamento compacto

- Corrige a serialização dos dados da carreira: calendários de partidas são salvos em tuplas compactas reversíveis, reduzindo a repetição de nomes e chaves.
- Ao carregar uma carreira, as tuplas são reconstruídas para o formato de objetos esperado pelo jogo.
- Preserva confrontos, placares, status de partida, rodadas, eventos, gols e campos extras dos calendários principal, ligas paralelas e histórico de temporadas.
- A rotina de salvamento continua tentando liberar apenas caches legados reconstruíveis se a primeira gravação falhar; não apaga carreiras nem histórico.
- Atualiza o nome do cache do service worker para forçar a instalação dos arquivos da versão nova.

## Validação executada

- Teste de ida e volta da compactação com calendário de 38 rodadas, placares, eventos e calendários aninhados: aprovado; exemplo de teste reduziu 139.808 para 78.248 caracteres (44%).
- Testes de recuperação de partidas, ligas, classificação, legado, quotas de calendários e Sub-20: aprovados.
- `tests/smoke-test.js` continua falhando na asserção preexistente `career systems initialized with identified real roster records`; isso não foi mascarado como sucesso.
- Não foi possível validar o comportamento em navegador Android/WebView real nesta execução.
