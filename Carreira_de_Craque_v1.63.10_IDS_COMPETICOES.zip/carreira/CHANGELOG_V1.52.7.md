# v1.52.7 — Legado baseado nos resultados reais da temporada

- A posição final do profissional é recalculada no encerramento a partir dos placares persistidos de todas as rodadas, não de uma tabela potencialmente desatualizada.
- A temporada concluída salva uma fotografia imutável da classificação ordenada, a posição de cada clube e os placares da temporada.
- O Legado reconstrói a posição histórica a partir dos resultados guardados naquela temporada (incluindo os calendários históricos por divisão), antes de usar campos antigos de posição como fallback.
- A ordenação final achata corretamente o calendário por rodadas antes de aplicar critérios de desempate direto.
- O título só é exibido quando os resultados daquela temporada confirmam a primeira posição.
- Cache PWA atualizado para v1.52.7.
