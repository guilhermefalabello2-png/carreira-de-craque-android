# Carreira de Craque v1.62.70b — Ligue 1 McDonald's

- Adicionada a França em “Escolher País e Clube” como **França - Ligue 1 McDonald’s (Profissional)**.
- Incluídos os 18 clubes informados pelo usuário, com os respectivos escudos PNG externos.
- Integrada a Ligue 1 à carreira profissional, com calendário de 34 rodadas (ida e volta), classificação e simulação junto à carreira.
- Adicionada a Ligue 1 ao menu de competições europeias.
- Aplicado tratamento branco à logo da Ligue 1 no seletor e na tela da competição.
- Incluída a Ligue 1 no seletor de destino do Mercado.
- Preservadas as demais ligas e funcionalidades existentes.
