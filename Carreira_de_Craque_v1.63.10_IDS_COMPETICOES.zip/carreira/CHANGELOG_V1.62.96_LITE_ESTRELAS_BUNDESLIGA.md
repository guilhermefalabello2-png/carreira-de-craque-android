# v1.62.96 LITE — Estrelas da Bundesliga

- Corrigida a avaliação por estrelas dos 18 clubes da Bundesliga.
- Bayern Munich recebe 5 estrelas; Borussia Dortmund, RB Leipzig e Bayer Leverkusen recebem 4,5.
- Frankfurt e Stuttgart recebem 4; Freiburg, Hoffenheim, Werder Bremen e Borussia Mönchengladbach recebem 3,5.
- Augsburg, Mainz, Union Berlin, Cologne, Hamburg e Schalke recebem 3; Paderborn e Elversberg recebem 2,5.
- A classificação é aplicada pela função central de avaliação, refletindo também no mercado, na força dos elencos e nas simulações que consultam as estrelas.
- Nenhuma carreira salva, elenco, escudo ou uniforme foi removido.
