# Carreira de Craque v1.52.1

## Correção de sincronização das rodadas
- A rodada da carreira passa a ser a referência para a Série A, B e C.
- Na abertura de saves antigos, rodadas simuladas além da rodada atual são desfeitas nos calendários paralelos, pois estavam adiantadas em relação à carreira.
- As tabelas das divisões são reconstruídas a partir dos placares válidos até a rodada sincronizada.
- O histórico da carreira e as estatísticas individuais não são apagados.

## Validação
- Sintaxe JavaScript e estrutura do ZIP verificadas.
- O teste dentro do app e com o save real do usuário ainda precisa ser realizado.
