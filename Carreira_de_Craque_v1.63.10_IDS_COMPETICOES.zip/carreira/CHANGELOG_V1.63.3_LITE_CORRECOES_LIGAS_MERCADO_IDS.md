# Carreira de Craque v1.63.3 LITE — Correções de Ligas, Mercado e IDs

- Corrigidas as logos de competição do Brasileirão Série A e Série B em Ligas: agora usam os arquivos locais `assets/trophies/brasileirao-serie-a.png` e `assets/trophies/brasileirao-serie-b.png`, sem depender de hospedagem externa.
- Mercado → Buscar Clube agora inclui todos os clubes da Serie A Enilive (Itália) e da Bundesliga (Alemanha), além das ligas já disponíveis.
- Cadastro central de clubes agora registra explicitamente os 18 clubes alemães com IDs determinísticos `GER-...`, estáveis e independentes de posição, divisão ou ordem da lista.
- Mantida a versão LITE e preservados os recursos e dados do jogo; nenhuma regra de competição ou elenco foi alterada.
