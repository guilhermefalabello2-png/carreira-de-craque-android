# v1.52.4 — Classificação e campeão corrigidos

- Ao encerrar a temporada, reconstrói a classificação da Série A/B/C a partir dos resultados realmente salvos.
- Recalcula as posições finais antes de registrar títulos e histórico.
- Corrige snapshots de divisões paralelas antes de determinar o campeão de cada competição.
- O campeão é sempre o primeiro colocado da classificação recalculada; o título do jogador depende de terminar em 1º na sua própria competição.
- Atualiza o cache do service worker para carregar os arquivos desta versão.

Validação local: sintaxe JavaScript, teste de classificação e integridade do ZIP. Ainda é necessário validar no aplicativo com um salvamento real.
