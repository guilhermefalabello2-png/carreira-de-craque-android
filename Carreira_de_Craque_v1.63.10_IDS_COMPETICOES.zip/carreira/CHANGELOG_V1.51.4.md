# Carreira de Craque v1.51.4

- Na tela **Início**, o botão de temporada encerrada agora ocupa o lugar principal do cartão onde aparecem Pré-jogo/Iniciar partida.
- Texto destacado exatamente como solicitado: **INICIAR NOVA TEMPORADA!**
- A ação continua ligada ao fluxo existente `newSeason`; o botão também recebe o mesmo rótulo na tela Partidas.
- Nenhuma mudança intencional em uniformes, elencos ou demais sistemas.
