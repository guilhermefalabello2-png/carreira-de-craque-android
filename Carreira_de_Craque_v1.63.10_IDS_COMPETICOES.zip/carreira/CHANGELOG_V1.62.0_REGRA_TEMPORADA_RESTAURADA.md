# Carreira de Craque v1.62.0 — Regra de permanência restaurada

- Restaurada a exigência de completar uma temporada no clube atual antes de solicitar, negociar ou concluir uma transferência.
- A regra usa a temporada em que o jogador chegou ao clube (`clubJoinedSeason`), com fallback pelo histórico de transferências para saves antigos.
- Mantidas as demais melhorias da versão 1.61.9, incluindo as correções do anúncio e da camisa do clube de destino.
