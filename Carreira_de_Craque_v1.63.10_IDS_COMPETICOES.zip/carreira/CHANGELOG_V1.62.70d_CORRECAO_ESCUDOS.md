# v1.62.70d — Correção dos escudos

- Restaurado integralmente o mapa original de escudos da v1.62.70b para os clubes brasileiros e demais ligas.
- Atualizados somente os 18 endereços PNG da Ligue 1.
- Mantida a função original `crest()` e os arquivos locais existentes.
- Os escudos remotos ainda dependem de conexão com a internet.
