# v1.62.20 — LaLiga no Mercado

- Adicionada a opção **Espanha — LaLiga** em Mercado → Escolha seu Destino.
- O seletor lista os 20 clubes da LaLiga e reutiliza escudos e estrelas já cadastrados.
- A seleção continua usando as regras existentes do empresário e da negociação; não altera a liga atual do atleta até uma transferência ser concluída.
- Atualizado o cache do service worker.
