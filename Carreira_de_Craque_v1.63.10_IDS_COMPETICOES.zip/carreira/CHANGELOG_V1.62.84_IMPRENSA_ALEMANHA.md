# Carreira de Craque v1.62.84 — Imprensa da Alemanha

- Adicionada cobertura editorial alemã para carreiras/partidas da Bundesliga.
- Portal esportivo: kicker, com identidade visual vermelha e identificação de futebol alemão.
- Três repórteres fictícios exclusivos: Lukas Schneider, Felix Hartmann e Jonas Weber.
- Coletivas passam a selecionar os três repórteres alemães; perguntas e respostas seguem o sistema existente.
- Manchetes automáticas pós-jogo em alemão para vitória, empate e clássico/derby.
- Roteamento baseado no país, liga e clubes alemães; demais países e imprensa existentes preservados.
- Nenhum save foi apagado e nenhum sistema de partidas foi alterado.
