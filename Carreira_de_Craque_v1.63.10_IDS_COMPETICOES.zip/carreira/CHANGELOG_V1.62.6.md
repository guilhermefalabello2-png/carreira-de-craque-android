# v1.62.6 — Sincronização da tabela de Ligas

- Corrigida a integração entre o calendário da carreira e o calendário independente exibido em **Ligas > Brasil**.
- Quando a partida do clube do usuário é concluída, o mesmo placar casa-fora é copiado para o confronto correspondente da divisão na tela Ligas, antes da simulação automática dos demais jogos.
- Os outros confrontos continuam sendo simulados normalmente; calendário, andamento da carreira, Copa do Brasil, elencos e salvamentos não são reiniciados.
- Mantida a persistência compacta dos resultados.
