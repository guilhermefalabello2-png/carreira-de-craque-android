# Carreira de Craque v1.60.9 — Clássicos com maior peso

## Melhorias
- Coletivas pós-jogo de clássicos agora priorizam três perguntas exclusivas sobre rivalidade, pressão da torcida, provocação e importância do resultado.
- Vitória em clássico aumenta a moral do jogador em 8 pontos.
- Derrota em clássico reduz a moral do jogador em 8 pontos.
- Empate não aplica bônus nem penalidade de moral por rivalidade.
- Consequência de moral é aplicada uma única vez por confronto, com proteção contra repetição do registro pós-jogo.
- Regras aplicadas aos clássicos reconhecidos no calendário profissional e também aos confrontos de copa identificados como rivalidades cadastradas.

## Preservação
- Não foram alterados uniformes, elencos, calendário, motor de partidas ou demais sistemas.
- O ajuste de moral é somado ao efeito normal da atuação individual; não substitui nota, gols, assistências ou confiança.
